/**
 * 
 */
package br.net.oi.intranet.gerenciadormensagens.web.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.opensymphony.oscache.util.StringUtil;

import br.net.oi.intranet.gerenciadormensagens.web.command.TreinamentoCommand;
import br.net.oi.poi_treinamento_business.bo.TreinamentoBO;
import br.net.oi.poi_treinamento_business.vo.TreinamentoVO;

/**
 * @author nino.r.montillano
 * @edited ronaldo.s.gagui
 */
@Controller
public class GerenciardorMensagensController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GerenciardorMensagensController.class);
	
	@Autowired
	public TreinamentoBO bo;
	
	/**
	 * @param bo the bo to set
	 */
	public void setBo(TreinamentoBO bo) {
		this.bo = bo;
	}

	/**
	 * Returns an instance of the object to bind AlterarCommand in the
	 * form
	 * 
	 * @return
	 */
	@ModelAttribute(value = "treinamentoCommand")
	public TreinamentoCommand getTreinamentCommandObject() {
		return new TreinamentoCommand();
	}

	/**
	 * This method will render the initial view of Gerenciar Mensagem
	 * 
	 * @return ModelAndView
	 * @throws Exception 
	 */
	@RequestMapping(value = "list")
	public ModelAndView list() throws Exception{ 
		ModelAndView modelAndView = new ModelAndView("list");
		
		try{
			modelAndView.addObject("listaNomes", bo.listAll());
		} catch (Exception e){
			LOGGER.error("Erro na busca da lista", e);
			throw e;
		}

		return modelAndView;
	}
	
	/**
	 * This method will render the initial view of Gerenciar Mensagem
	 * 
	 * @return ModelAndView
	 */
	@RequestMapping(value = "insert")
	public ModelAndView render(){
		ModelAndView modelAndView = new ModelAndView("view");
		modelAndView.addObject("acao", "I");
		modelAndView.addObject("ietmTreinamento", new TreinamentoVO());
		return modelAndView;
	}
	
	/**
	 * This method will render the initial view of Gerenciar Mensagem
	 * 
	 * @return ModelAndView
	 * @throws Exception 
	 */
	@RequestMapping(value = "edit")
	public ModelAndView edit(@RequestParam(value="id") int id) throws Exception{
		ModelAndView modelAndView = new ModelAndView("view");
		
		try {
			TreinamentoVO vo = bo.listById(id);
			modelAndView.addObject("acao", "E");
			modelAndView.addObject("id", id);
			modelAndView.addObject("treinamentoCommand", criaCommand(vo));
		} catch (Exception e) {
			LOGGER.error("Erro na busca da lista", e);
			throw e;
		}
		
		return modelAndView;
	}
	
	/**
	 * This method will render the initial view of Gerenciar Mensagem
	 * 
	 * @return ModelAndView
	 * @throws Exception 
	 */
	@RequestMapping(value = "delete")
	public ModelAndView delete(@RequestParam(value="id") int id) throws Exception{
		ModelAndView modelAndView = new ModelAndView("success");
		try {
			bo.delete(id);
		} catch (Exception e) {
			LOGGER.error("Erro na busca da lista", e);
			throw e;
		}
		
		return modelAndView;
	}
	
	@RequestMapping(value = "formSubmit")
	public String submi(
			@RequestParam (value="acao") String acao,
			@RequestParam (value="id") String id,
			@ModelAttribute(value = "treinamentoCommand") @Valid TreinamentoCommand cmd,
			BindingResult result) throws Exception{
		//ModelAndView modelAndView = new ModelAndView("success");
		
		if (result.hasErrors()) {
			//modelAndView.setViewName("view");
			return "view";
		}
		
		try {
			TreinamentoVO vo = criaVO(id, cmd);
			if ("E".equals(acao)){
				bo.update(vo);
			} else if ("I".equals(acao)){
				bo.insert(vo);
			} else {
				return "error/";
			}
		} catch (Exception e) {
			LOGGER.error("Erro na busca da lista", e);
			throw e;
		}
		
		return "success";
	}
	
	private TreinamentoCommand criaCommand(TreinamentoVO vo){
		TreinamentoCommand cmd = new TreinamentoCommand();
		cmd.setNome(vo.getNome());
		cmd.setTelefone(vo.getTelefone());
		return cmd;
	}
	
	private TreinamentoVO criaVO(String id, TreinamentoCommand cmd){
		TreinamentoVO vo = new TreinamentoVO();
		
		if(!StringUtil.isEmpty(id)){
			vo.setCod(new Integer(id).intValue());
		}
		
		vo.setNome(cmd.getNome());
		vo.setTelefone(cmd.getTelefone());
		return vo;
	}
}
