/**
 * 
 */
package br.net.oi.poi_treinamento_business.dao.impl;

import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import br.net.oi.poi_treinamento_business.dao.TreinamentoDAO;
import br.net.oi.poi_treinamento_business.vo.TreinamentoVO;

/**
 * @author marconi.cauzin
 *
 */
public class JDBCTreinamentoDAO extends JdbcTemplate implements TreinamentoDAO {

	private final String LIST = "select cod, nome, fone as telefone from agenda_telefonica";

	private final String LISTBYID = "select cod, nome, fone as telefone from agenda_telefonica where cod=?";

	private final String INSERT = "INSERT INTO AGENDA_TELEFONICA VALUES (SEQ_AGENDA.nextval, ?, ?, SYSDATE)";

	private final String UPDATE = "UPDATE AGENDA_TELEFONICA SET nome=?, fone=? WHERE cod=?";

	private final String DELETE = "delete from AGENDA_TELEFONICA WHERE cod=?";

	public JDBCTreinamentoDAO(DataSource dataSource) {
		super(dataSource);
		// TODO Auto-generated constructor stub
	}

	public List<TreinamentoVO> listAll() {

		List<TreinamentoVO> res = this.query(LIST, new BeanPropertyRowMapper<TreinamentoVO>(TreinamentoVO.class));
		return res;
	}

	public boolean insert(TreinamentoVO vo) {
		Object aobj[];
		aobj = new Object[2];
		aobj[0] = vo.getNome();
		aobj[1] = vo.getTelefone();

		this.update(INSERT, aobj, new int[] { Types.VARCHAR, Types.VARCHAR });
		return true;
	}

	public boolean update(TreinamentoVO vo) {
		Object aobj[];
		aobj = new Object[3];
		aobj[0] = vo.getNome();
		aobj[1] = vo.getTelefone();
		aobj[2] = vo.getCod();

		this.update(UPDATE, aobj, new int[] { Types.VARCHAR, Types.VARCHAR, Types.INTEGER });
		return true;
	}

	public void delete(int id) {

		Object aobj[];
		aobj = new Object[1];
		aobj[0] = id;
		this.update(DELETE, aobj, new int[] { Types.INTEGER });

	}

	public TreinamentoVO listByID(int id) {

		Object aobj[];
		aobj = new Object[1];
		aobj[0] = id;
		return this.queryForObject(LISTBYID, aobj, new int[] { Types.INTEGER },
				new BeanPropertyRowMapper<TreinamentoVO>(TreinamentoVO.class));
	}

}
