package br.net.oi.poi_treinamento_business.bo.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.net.oi.poi_treinamento_business.bo.TreinamentoBO;
import br.net.oi.poi_treinamento_business.dao.TreinamentoDAO;
import br.net.oi.poi_treinamento_business.vo.TreinamentoVO;

/**
 * Classe contendo as regras de Negócio
 * 
 */
@Service("TreinamentoBOImpl")
public class TreinamentoBOImpl implements TreinamentoBO {

	@Autowired
	public TreinamentoDAO dao;

	private static final Logger log = LoggerFactory.getLogger(TreinamentoBOImpl.class);

	public List<TreinamentoVO> listAll() {
		log.debug("BO ListAll - start");
		return dao.listAll();

	}

	public TreinamentoVO listById(int id) {
		
		return dao.listByID(id);
	}

	public boolean insert(TreinamentoVO vo) {
		
		return dao.insert(vo);
	}

	public boolean update(TreinamentoVO vo) {
		
		return dao.update(vo);
	}

	public void delete(int id) {

		dao.delete(id);
	}

	/**
	 * @param dao
	 *            the dao to set
	 */
	public void setDao(TreinamentoDAO dao) {
		this.dao = dao;
	}

}