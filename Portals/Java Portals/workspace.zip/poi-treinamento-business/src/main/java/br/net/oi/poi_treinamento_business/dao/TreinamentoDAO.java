/**
 * 
 */
package br.net.oi.poi_treinamento_business.dao;

import java.util.List;

import br.net.oi.poi_treinamento_business.vo.TreinamentoVO;

/**
 * @author marconi.cauzin
 *
 */
public interface TreinamentoDAO {

	public List<TreinamentoVO> listAll();
	
	public TreinamentoVO listByID(int id);
	
	public boolean insert(TreinamentoVO vo);
	
	public boolean update(TreinamentoVO vo);
	
	public void delete(int id);
}
