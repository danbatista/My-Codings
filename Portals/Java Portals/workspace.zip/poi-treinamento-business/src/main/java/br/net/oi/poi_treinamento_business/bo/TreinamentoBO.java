package br.net.oi.poi_treinamento_business.bo;



import java.util.List;

import br.net.oi.poi_treinamento_business.vo.TreinamentoVO;

/**
 * Interface contendo as operacoes de Negócio
 *
 */
public interface TreinamentoBO {
	
	public List<TreinamentoVO> listAll();
	
	public TreinamentoVO listById(int id);
	
	public boolean insert(TreinamentoVO vo);
	
	public boolean update(TreinamentoVO vo);
	
	public void delete(int id);

}
